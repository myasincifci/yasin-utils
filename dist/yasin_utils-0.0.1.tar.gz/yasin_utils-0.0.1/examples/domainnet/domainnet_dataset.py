from yasin_utils import ImageDataset

class DomainNetDataset(ImageDataset):
    def __init__(self, root: str, transform=None) -> None:
        set_map = None

        super().__init__(set_map, transform)

def main():
    dataset = DomainNetDataset()

if __name__ == '__main__':
    main()